#!/bin/bash

echo "🚀 FinSight 财智眼 - GitHub 推送脚本"
echo "=================================="

echo "📋 推送前准备："
echo "1. 访问 https://github.com/settings/tokens"
echo "2. 点击 'Generate new token (classic)'"
echo "3. 选择 'repo' 权限"
echo "4. 复制生成的token"
echo ""

read -p "请输入你的GitHub Personal Access Token: " token

if [ -z "$token" ]; then
    echo "❌ 错误: Token不能为空"
    exit 1
fi

echo "⬆️ 正在推送到GitHub..."

# 使用token推送
git push https://$token@github.com/JasonX-coder/finsight-ai-financial-analysis.git main

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 推送成功！"
    echo "🌐 访问你的仓库: https://github.com/JasonX-coder/finsight-ai-financial-analysis"
    echo ""
    echo "📋 下一步："
    echo "1. 在GitHub仓库设置中添加Secrets:"
    echo "   - GEMINI_API_KEY"
    echo "   - DOUBAO_API_KEY"
    echo "2. 启用GitHub Pages"
    echo "3. 等待自动部署完成"
else
    echo "❌ 推送失败，请检查token是否正确"
fi
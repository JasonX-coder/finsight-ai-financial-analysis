#!/bin/bash

# FinSight 财智眼 - GitHub 部署脚本
# 使用方法: ./scripts/deploy-to-github.sh [repository-url]

set -e

echo "🚀 FinSight 财智眼 - GitHub 部署脚本"
echo "=================================="

# 检查是否提供了仓库URL
if [ -z "$1" ]; then
    echo "❌ 错误: 请提供 GitHub 仓库 URL"
    echo "使用方法: ./scripts/deploy-to-github.sh https://github.com/username/repository.git"
    exit 1
fi

REPO_URL=$1

# 检查是否已经是Git仓库
if [ ! -d ".git" ]; then
    echo "📦 初始化 Git 仓库..."
    git init
else
    echo "✅ Git 仓库已存在"
fi

# 检查环境变量文件
if [ ! -f ".env.local" ]; then
    echo "⚠️  警告: .env.local 文件不存在，正在创建模板..."
    cp .env.example .env.local
    echo "请编辑 .env.local 文件并添加你的 API Keys"
fi

# 添加所有文件到暂存区
echo "📁 添加文件到 Git..."
git add .

# 检查是否有更改需要提交
if git diff --staged --quiet; then
    echo "✅ 没有新的更改需要提交"
else
    echo "💾 提交更改..."
    git commit -m "feat: 初始化 FinSight 财智眼项目

- 添加完整的项目结构和源代码
- 配置多种部署方式 (Vercel, Netlify, Docker)
- 添加 GitHub Actions 自动化部署
- 完善项目文档和部署指南"
fi

# 检查是否已经添加了远程仓库
if git remote get-url origin >/dev/null 2>&1; then
    echo "✅ 远程仓库已配置"
    CURRENT_REMOTE=$(git remote get-url origin)
    if [ "$CURRENT_REMOTE" != "$REPO_URL" ]; then
        echo "🔄 更新远程仓库 URL: $REPO_URL"
        git remote set-url origin "$REPO_URL"
    fi
else
    echo "🔗 添加远程仓库: $REPO_URL"
    git remote add origin "$REPO_URL"
fi

# 推送到GitHub
echo "⬆️  推送到 GitHub..."
git branch -M main
git push -u origin main

echo ""
echo "🎉 部署完成！"
echo "=================================="
echo "📍 GitHub 仓库: $REPO_URL"
echo "🌐 在线访问: https://your-username.github.io/repository-name"
echo ""
echo "📋 后续步骤:"
echo "1. 在 GitHub 仓库设置中配置 Secrets:"
echo "   - GEMINI_API_KEY: 你的 Gemini API 密钥"
echo "   - DOUBAO_API_KEY: 你的豆包 API 密钥"
echo "2. 启用 GitHub Pages (Settings > Pages > Source: GitHub Actions)"
echo "3. 等待 GitHub Actions 自动部署完成"
echo ""
echo "🚀 享受你的 FinSight 财智眼应用吧！"
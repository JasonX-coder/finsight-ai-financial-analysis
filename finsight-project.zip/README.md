# FinSight 财智眼 🚀

<div align="center">

**一眼看穿财报，十秒读懂公司**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js Version](https://img.shields.io/badge/node-%3E%3D18-brightgreen)](https://nodejs.org/)
[![React](https://img.shields.io/badge/React-19.2.0-blue)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.8.2-blue)](https://www.typescriptlang.org/)

[在线体验](https://ai.studio/apps/drive/1GlZ9GnCmhcD80mW0h7sc4-y-Rm7LcbO3) | [部署指南](./DEPLOYMENT.md) | [项目介绍](./PROJECT_INTRODUCTION.md)

</div>

## ✨ 项目简介

FinSight 财智眼是一款基于 AI 驱动的智能财报分析工具，旨在帮助投资者快速理解和分析上市公司的财务状况。通过 Google Gemini 2.5 Flash 和实时数据检索技术，为用户提供专业级的财务分析体验。

### 🎯 核心功能

- 🔍 **全球股票实时检索** - 支持股票代码/公司名称搜索，实时获取财务数据
- 📊 **多维度分析仪表盘** - FinSight 评分、能力雷达图、业绩趋势图
- 📄 **财报文档智能解析** - 支持 PDF/图片上传，AI 自动提取关键数据  
- 🤖 **AI 深度问答** - 基于分析数据的智能对话，支持专业财务问题
- ⚠️ **风险监控系统** - 自动识别风险因素，支持自定义预警规则
- 📋 **投资研报导出** - 一键生成专业投资备忘录

### 🛠️ 技术栈

- **前端**: React 19 + TypeScript + Vite + Tailwind CSS
- **图表**: Recharts 数据可视化
- **AI 服务**: Google Gemini 2.5 Flash + Search Grounding
- **部署**: 支持 Vercel、Netlify、Docker 等多种部署方式

## 🚀 快速开始

### 环境要求

- Node.js 18+
- npm 或 yarn
- Google Gemini API Key

### 本地运行

1. **克隆项目**
```bash
git clone https://github.com/your-username/finsight-ai-financial-analysis.git
cd finsight-ai-financial-analysis
```

2. **安装依赖**
```bash
npm install
```

3. **配置环境变量**
```bash
# 复制环境变量模板
cp .env.example .env.local

# 编辑 .env.local，添加你的 API Keys
GEMINI_API_KEY=your_gemini_api_key_here
DOUBAO_API_KEY=your_doubao_api_key_here
```

4. **启动开发服务器**
```bash
npm run dev
```

5. **访问应用**
打开浏览器访问 `http://localhost:5173`

## 📦 部署方式

### Vercel 一键部署

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/finsight-ai-financial-analysis)

### Docker 部署

```bash
# 构建镜像
docker build -t finsight-app .

# 运行容器
docker run -p 80:80 finsight-app
```

### Docker Compose

```bash
docker-compose up -d
```

更多部署方式请查看 [部署指南](./DEPLOYMENT.md)

## 📸 应用截图

### 主界面
- 股票搜索和实时分析
- FinSight 综合评分展示
- 六维度能力雷达图

### 分析仪表盘  
- 关键财务指标卡片
- 2023-2025年业绩趋势图
- 风险因素识别

### AI 问答功能
- 智能财务问题解答
- 多轮对话支持
- 专业投资建议

## 🔧 项目结构

```
├── App.tsx                 # 主应用组件
├── components/
│   ├── Charts.tsx          # 图表组件（雷达图、趋势图）
│   └── Icons.tsx           # SVG 图标组件
├── services/
│   ├── geminiService.ts    # Gemini AI 服务
│   └── doubaoService.ts    # 豆包 AI 服务
├── types.ts                # TypeScript 类型定义
├── constants.ts            # 常量配置
└── ...
```

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 🙏 致谢

- [Google Gemini](https://ai.google.dev/) - 提供强大的 AI 能力
- [Recharts](https://recharts.org/) - 优秀的 React 图表库
- [Tailwind CSS](https://tailwindcss.com/) - 实用的 CSS 框架

## 📞 联系我们

- 项目地址: [GitHub](https://github.com/your-username/finsight-ai-financial-analysis)
- 问题反馈: [Issues](https://github.com/your-username/finsight-ai-financial-analysis/issues)
- 在线体验: [AI Studio](https://ai.studio/apps/drive/1GlZ9GnCmhcD80mW0h7sc4-y-Rm7LcbO3)

---

⭐ 如果这个项目对你有帮助，请给我们一个 Star！


import { CompanyData, ChatMessage } from "../types";

const API_KEY = process.env.API_KEY || '';
const MODEL_ID = 'doubao-1-5-pro-32k-250115';
const API_BASE_URL = 'https://ark.cn-beijing.volces.com/api/v3';

// 请求超时时间（毫秒）
const REQUEST_TIMEOUT = 600000; // 10分钟

// 自定义错误类型
export class APIError extends Error {
  type: 'timeout' | 'network' | 'parse' | 'api' | 'unknown';
  
  constructor(type: APIError['type'], message: string) {
    super(message);
    this.type = type;
    this.name = 'APIError';
  }
}

// 错误消息映射
const ERROR_MESSAGES = {
  timeout: '请求超时（超过10分钟）。可能原因：\n• 网络连接不稳定\n• AI 搜索数据量过大\n\n建议：请稍后重试，或尝试输入更具体的公司名称/股票代码。',
  network: '网络连接失败。可能原因：\n• 网络中断或不稳定\n• API 服务暂时不可用\n• 防火墙或代理限制\n\n建议：请检查网络连接后重试。',
  parse: 'AI 返回数据格式异常。可能原因：\n• 该公司数据较少，AI 无法生成完整报告\n• AI 响应被截断\n\n建议：尝试搜索更知名的上市公司。',
  api: 'AI 服务返回错误。可能原因：\n• API 配额已用尽\n• API Key 无效\n• 服务暂时过载\n\n建议：请稍后重试。',
  unknown: '发生未知错误。请稍后重试，如问题持续请刷新页面。'
};

// 获取用户友好的错误消息
export const getErrorMessage = (error: unknown): string => {
  if (error instanceof APIError) {
    return ERROR_MESSAGES[error.type];
  }
  return ERROR_MESSAGES.unknown;
};

// 带超时的 Promise 包装器
const withTimeout = <T>(promise: Promise<T>, ms: number): Promise<T> => {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new APIError('timeout', `Request timed out after ${ms}ms`));
    }, ms);
    
    promise
      .then(result => {
        clearTimeout(timer);
        resolve(result);
      })
      .catch(err => {
        clearTimeout(timer);
        reject(err);
      });
  });
};

// 分析错误类型
const classifyError = (error: unknown): APIError => {
  // 已经是 APIError
  if (error instanceof APIError) {
    return error;
  }
  
  const errorMessage = error instanceof Error ? error.message.toLowerCase() : String(error).toLowerCase();
  const errorName = error instanceof Error ? error.name : '';
  
  // 超时错误
  if (
    errorMessage.includes('timeout') ||
    errorMessage.includes('timed out') ||
    errorMessage.includes('aborted') ||
    errorName === 'AbortError'
  ) {
    return new APIError('timeout', errorMessage);
  }
  
  // 网络错误
  if (
    errorMessage.includes('network') ||
    errorMessage.includes('fetch') ||
    errorMessage.includes('failed to fetch') ||
    errorMessage.includes('net::') ||
    errorMessage.includes('connection') ||
    errorMessage.includes('econnrefused') ||
    errorMessage.includes('enotfound') ||
    errorName === 'TypeError' // fetch 失败通常是 TypeError
  ) {
    return new APIError('network', errorMessage);
  }
  
  // API 错误
  if (
    errorMessage.includes('api') ||
    errorMessage.includes('quota') ||
    errorMessage.includes('rate limit') ||
    errorMessage.includes('unauthorized') ||
    errorMessage.includes('forbidden') ||
    errorMessage.includes('invalid') ||
    errorMessage.includes('400') ||
    errorMessage.includes('401') ||
    errorMessage.includes('403') ||
    errorMessage.includes('429') ||
    errorMessage.includes('500') ||
    errorMessage.includes('503')
  ) {
    return new APIError('api', errorMessage);
  }
  
  // 解析错误
  if (
    errorMessage.includes('json') ||
    errorMessage.includes('parse') ||
    errorMessage.includes('syntax') ||
    errorMessage.includes('unexpected token')
  ) {
    return new APIError('parse', errorMessage);
  }
  
  return new APIError('unknown', errorMessage);
};

// Robust JSON cleaner to extract valid JSON object from mixed text
const cleanJsonString = (text: string): string => {
  if (!text) return "{}";
  
  // 1. Remove Markdown code blocks if present
  let cleaned = text.replace(/```json/g, '').replace(/```/g, '');
  
  // 2. Find the first '{' and the last '}'
  const firstOpen = cleaned.indexOf('{');
  const lastClose = cleaned.lastIndexOf('}');
  
  // 3. Extract the substring
  if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
    cleaned = cleaned.substring(firstOpen, lastClose + 1);
  }
  
  return cleaned.trim();
};

// 调用豆包 API
const callDoubaoAPI = async (
  messages: Array<{ role: string; content: string | Array<any> }>,
  temperature: number = 0.7
): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL_ID,
      messages: messages,
      temperature: temperature,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API Error: ${response.status} ${errorText}`);
  }

  const data = await response.json();
  
  if (!data.choices || !data.choices[0] || !data.choices[0].message) {
    throw new APIError('api', 'API 返回格式异常');
  }

  return data.choices[0].message.content || '';
};

// Define the expected structure for the AI to fill
// Optimized: Reduced trends to 3 years and removed rawTextContext to prevent timeouts
const DATA_STRUCTURE_PROMPT = `
请严格按照以下 JSON 格式返回数据。
重要原则：
1. 必须返回纯 JSON 字符串，不要包含任何对话、前言或 Markdown 标记。
2. 如果搜索不到某个具体数据，请基于行业常识进行**合理估算**，或者填入 0，**绝对不要**破坏 JSON 结构。
3. 所有文本内容必须使用中文。

JSON 结构模板：
{
  "ticker": "股票代码",
  "name": "公司名称",
  "industry": "所属行业",
  "finSightScore": 0-100之间的整数评分,
  "summary": "一段简短的财务状况总结（100字以内）",
  "metrics": {
    "roe": { "label": "净资产收益率 (ROE)", "value": 数值(保留1位小数), "unit": "%", "change": 同比变化百分比(数值), "status": "good"|"neutral"|"bad" },
    "grossMargin": { "label": "毛利率", "value": 数值, "unit": "%", "change": 数值, "status": "good"|"neutral"|"bad" },
    "peRatio": { "label": "市盈率 (TTM)", "value": 数值, "unit": "x", "change": 数值, "status": "good"|"neutral"|"bad" },
    "debtToAsset": { "label": "资产负债率", "value": 数值, "unit": "%", "change": 数值, "status": "good"|"neutral"|"bad" },
    "netMargin": { "label": "净利率", "value": 数值, "unit": "%", "change": 数值, "status": "good"|"neutral"|"bad" },
    "currentRatio": { "label": "流动比率", "value": 数值, "unit": "x", "change": 数值, "status": "good"|"neutral"|"bad" },
    "freeCashFlow": { "label": "自由现金流", "value": 数值, "unit": "亿", "change": 数值, "status": "good"|"neutral"|"bad" },
    "revenueGrowth": { "label": "营收增长率", "value": 数值, "unit": "%", "change": 数值, "status": "good"|"neutral"|"bad" }
  },
  "dimensions": [
    { "subject": "成长能力", "A": 0-100评分, "B": 行业平均分(0-100), "fullMark": 100 },
    { "subject": "盈利能力", "A": 0-100评分, "B": 行业平均分(0-100), "fullMark": 100 },
    { "subject": "估值水平", "A": 0-100评分, "B": 行业平均分(0-100), "fullMark": 100 },
    { "subject": "财务安全", "A": 0-100评分, "B": 行业平均分(0-100), "fullMark": 100 },
    { "subject": "现金流", "A": 0-100评分, "B": 行业平均分(0-100), "fullMark": 100 },
    { "subject": "ESG评分", "A": 0-100评分, "B": 行业平均分(0-100), "fullMark": 100 }
  ],
  "trends": [
    // 2023-2025年的数据（包含预测值）
    { "year": "2023", "revenue": 营收数值(亿), "netProfit": 净利润数值(亿), "cashFlow": 现金流数值(亿) },
    { "year": "2024", "revenue": 数值, "netProfit": 数值, "cashFlow": 数值 },
    { "year": "2025", "revenue": 数值, "netProfit": 数值, "cashFlow": 数值 }
  ],
  "risks": [
    { "id": "1", "severity": "high"|"medium"|"low", "category": "风险类别", "description": "风险描述" },
    { "id": "2", "severity": "high"|"medium"|"low", "category": "风险类别", "description": "风险描述" },
    { "id": "3", "severity": "high"|"medium"|"low", "category": "风险类别", "description": "风险描述" }
  ]
}
`;

/**
 * Fetch company data (for Ticker search)
 * Note: Doubao API doesn't support Google Search Grounding, so we rely on the model's training data
 */
export const fetchCompanyData = async (query: string): Promise<CompanyData> => {
  const today = new Date().toLocaleDateString('zh-CN');
  const prompt = `
    当前日期: ${today}
    请基于你的知识库，分析关于 "${query}" (股票代码或公司名) 的最新财务报告数据。
    
    任务：
    1. 分析该公司的最新财务核心指标、营收趋势、风险因素。
    2. 像一位专业的金融分析师一样，对数据进行结构化整理。
    3. 无论数据是否完整，都**必须**返回完整的 JSON 对象。如果某些具体年份的数据缺失，请根据最新数据进行合理的前向或后向估算。
    4. ${DATA_STRUCTURE_PROMPT}
  `;

  let responseText: string;
  try {
    // 使用超时包装 API 调用
    responseText = await withTimeout(
      callDoubaoAPI([
        {
          role: 'user',
          content: prompt
        }
      ], 0.2),
      REQUEST_TIMEOUT
    );
  } catch (error) {
    console.error("Fetch Data Error:", error);
    throw classifyError(error);
  }

  // 解析响应
  if (!responseText) {
    throw new APIError('api', 'AI 返回空响应');
  }
  
  const jsonStr = cleanJsonString(responseText);
  
  try {
    const data = JSON.parse(jsonStr) as CompanyData;
    if (!data.metrics || !data.dimensions || !data.trends) {
      throw new APIError('parse', 'JSON 结构缺失关键字段');
    }
    return data;
  } catch (parseError) {
    console.error("JSON Parse Error:", parseError, "Cleaned JSON:", jsonStr.substring(0, 500));
    if (parseError instanceof APIError) {
      throw parseError;
    }
    throw new APIError('parse', 'JSON 解析失败');
  }
};

/**
 * Parse uploaded financial report (PDF/Text)
 */
export const parseFinancialFile = async (fileBase64: string, mimeType: string): Promise<CompanyData> => {
  const today = new Date().toLocaleDateString('zh-CN');
  const prompt = `
    当前日期: ${today}
    你是一个顶级投行分析师。请阅读提供的文档（可能是年报或招股书），提取关键财务数据。
    
    重要提示：
    1. 文档可能很长（如招股书），请专注于提取**最近三年**的合并财务报表数据。
    2. 如果文档中包含多个实体，以**集团合并报表**为准。
    3. 如果因为文档扫描不清或页面缺失导致数据不全，请基于文档中已有的信息进行**合理推算**补全，确保返回的 JSON 结构是完整的。
    4. ${DATA_STRUCTURE_PROMPT}
  `;

  let responseText: string;
  try {
    // 文件解析使用统一的超时时间
    // 构建多模态消息内容
    const content: Array<any> = [
      {
        type: 'image_url',
        image_url: {
          url: `data:${mimeType};base64,${fileBase64}`
        }
      },
      {
        type: 'text',
        text: prompt
      }
    ];

    responseText = await withTimeout(
      callDoubaoAPI([
        {
          role: 'user',
          content: content
        }
      ], 0.2),
      REQUEST_TIMEOUT // 10分钟
    );
  } catch (error) {
    console.error("File Parse Error:", error);
    throw classifyError(error);
  }

  if (!responseText) {
    throw new APIError('api', 'AI 返回空响应');
  }
  
  const jsonStr = cleanJsonString(responseText);

  try {
    const data = JSON.parse(jsonStr) as CompanyData;
    if (!data.metrics || !data.dimensions || !data.trends) {
      throw new APIError('parse', 'JSON 结构缺失关键字段');
    }
    return data;
  } catch (parseError) {
    console.error("JSON Parse Error:", parseError, "Raw Text:", responseText.substring(0, 500));
    if (parseError instanceof APIError) {
      throw parseError;
    }
    throw new APIError('parse', 'AI 无法解析文件内容，请确保上传的是合法的财报 PDF 或图片文件');
  }
};

/**
 * Generate a professional investment memo in Markdown
 */
export const generateInvestmentMemo = async (data: CompanyData): Promise<string> => {
  try {
    const today = new Date().toLocaleDateString('zh-CN');
    
    // Construct a condensed data string to save tokens
    const dataSummary = JSON.stringify({
      name: data.name,
      ticker: data.ticker,
      metrics: data.metrics,
      risks: data.risks,
      summary: data.summary,
      trends: data.trends
    });

    const prompt = `
      当前日期: ${today}
      作为一位顶级基金经理，请基于以下财务数据，写一份深度的**投资研报 (Investment Memo)**。
      
      [数据]
      ${dataSummary}
      
      [格式要求]
      1. 使用 Markdown 格式。
      2. 字数：1500字左右。
      3. 语言：中文。
      4. 结构：
         - **# 投资概要 (Investment Thesis)**: 核心买入/卖出逻辑。
         - **# 关键财务分析**: 解读 ROE、毛利率和未来三年的增长趋势(2023-2025)。
         - **# 估值评价**: 当前估值水平分析。
         - **# 风险提示**: 重点风险点。
         - **# 最终建议**: 买入 / 增持 / 中性 / 卖出。
      5. 请在报告开头明确标出"报告日期: ${today}"。
    `;

    const responseText = await callDoubaoAPI([
      {
        role: 'user',
        content: prompt
      }
    ], 0.7);

    return responseText || "生成研报失败，请重试。";
  } catch (error) {
    console.error("Generate Memo Error:", error);
    return "AI 服务暂时不可用，无法生成研报。";
  }
};

/**
 * Chat with the analyzed data
 */
export const generateAIAnalysis = async (
  companyData: CompanyData, 
  userQuery?: string, 
  history: ChatMessage[] = []
): Promise<string> => {
  try {
    const risksText = companyData.risks.map(r => `- [${r.severity === 'high' ? '高危' : '注意'}] ${r.category}: ${r.description}`).join('\n');
    const metricsText = Object.entries(companyData.metrics).map(([k, v]) => `${v.label}: ${v.value}${v.unit}`).join(', ');

    const systemPrompt = `
      你是 FinSight AI，一位世界级的金融分析师。
      你正在分析 ${companyData.name} (${companyData.ticker}) 的数据。
      当前日期: ${new Date().toLocaleDateString('zh-CN')}
      
      [核心数据]
      FinSight 总分: ${companyData.finSightScore}
      财务摘要: ${companyData.summary}
      
      [关键指标]
      ${metricsText}
      
      [主要风险]
      ${risksText}
    `;

    const messages: Array<{ role: string; content: string }> = [
      {
        role: 'system',
        content: systemPrompt
      }
    ];

    // 添加历史对话
    if (history.length > 0) {
      history.forEach(msg => {
        messages.push({
          role: msg.role === 'user' ? 'user' : 'assistant',
          content: msg.content
        });
      });
    }

    // 添加当前用户问题
    if (userQuery) {
      messages.push({
        role: 'user',
        content: userQuery
      });
    } else {
      messages.push({
        role: 'user',
        content: '请用中文简要点评该公司的投资价值。'
      });
    }

    const responseText = await callDoubaoAPI(messages, 0.7);

    return responseText || "暂时无法生成回答。";
  } catch (error) {
    console.error("Doubao Chat Error:", error);
    return "AI 服务暂时不可用。";
  }
};

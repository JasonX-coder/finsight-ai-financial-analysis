# FinSight 财智眼 - 部署指南

## 目录
- [本地开发部署](#本地开发部署)
- [生产环境部署](#生产环境部署)
- [Docker 部署](#docker-部署)
- [环境变量配置](#环境变量配置)
- [常见问题](#常见问题)

## 本地开发部署

### 环境要求
- Node.js 18+ 
- npm 或 yarn
- Git

### 快速开始

1. **克隆项目**
```bash
git clone https://github.com/your-username/finsight-ai-financial-analysis.git
cd finsight-ai-financial-analysis
```

2. **安装依赖**
```bash
npm install
```

3. **配置环境变量**
```bash
# 复制环境变量模板
cp .env.example .env.local

# 编辑 .env.local 文件，添加你的 API Keys
GEMINI_API_KEY=your_gemini_api_key_here
DOUBAO_API_KEY=your_doubao_api_key_here
```

4. **启动开发服务器**
```bash
npm run dev
```

5. **访问应用**
打开浏览器访问 `http://localhost:5173`

## 生产环境部署

### Vercel 部署（推荐）

1. **准备项目**
```bash
npm run build
```

2. **部署到 Vercel**
```bash
# 安装 Vercel CLI
npm i -g vercel

# 登录并部署
vercel login
vercel --prod
```

3. **配置环境变量**
在 Vercel Dashboard 中设置环境变量：
- `GEMINI_API_KEY`
- `DOUBAO_API_KEY`

### Netlify 部署

1. **构建项目**
```bash
npm run build
```

2. **部署到 Netlify**
- 将 `dist` 文件夹拖拽到 Netlify 部署页面
- 或使用 Netlify CLI：
```bash
npm install -g netlify-cli
netlify deploy --prod --dir=dist
```

### 传统服务器部署

1. **构建项目**
```bash
npm run build
```

2. **配置 Nginx**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        root /path/to/your/dist;
        try_files $uri $uri/ /index.html;
    }
}
```

3. **启动服务**
```bash
sudo systemctl reload nginx
```

## Docker 部署

### 创建 Dockerfile
```dockerfile
# 构建阶段
FROM node:18-alpine as builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

# 生产阶段
FROM nginx:alpine

COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### 构建和运行
```bash
# 构建镜像
docker build -t finsight-app .

# 运行容器
docker run -p 80:80 finsight-app
```

### Docker Compose
```yaml
version: '3.8'
services:
  finsight:
    build: .
    ports:
      - "80:80"
    environment:
      - GEMINI_API_KEY=${GEMINI_API_KEY}
      - DOUBAO_API_KEY=${DOUBAO_API_KEY}
```

## 环境变量配置

### 必需的环境变量

| 变量名 | 描述 | 获取方式 |
|--------|------|----------|
| `GEMINI_API_KEY` | Google Gemini API 密钥 | [Google AI Studio](https://makersuite.google.com/app/apikey) |
| `DOUBAO_API_KEY` | 豆包 API 密钥 | [火山引擎控制台](https://console.volcengine.com/) |

### 可选的环境变量

| 变量名 | 描述 | 默认值 |
|--------|------|--------|
| `VITE_APP_TITLE` | 应用标题 | "FinSight 财智眼" |
| `VITE_API_TIMEOUT` | API 超时时间(ms) | 30000 |

### 环境变量模板 (.env.example)
```bash
# Google Gemini API Key
GEMINI_API_KEY=your_gemini_api_key_here

# 豆包 API Key  
DOUBAO_API_KEY=your_doubao_api_key_here

# 可选配置
VITE_APP_TITLE=FinSight 财智眼
VITE_API_TIMEOUT=30000
```

## 性能优化

### 构建优化
```bash
# 分析构建包大小
npm run build -- --analyze

# 启用 gzip 压缩
npm install --save-dev vite-plugin-compression
```

### CDN 配置
推荐使用 CDN 加速静态资源：
- Cloudflare
- AWS CloudFront
- 阿里云 CDN

## 监控和日志

### 错误监控
推荐集成：
- Sentry
- LogRocket
- Bugsnag

### 性能监控
- Google Analytics
- Vercel Analytics
- Plausible

## 安全配置

### HTTPS 配置
确保生产环境启用 HTTPS：
```bash
# Let's Encrypt 证书
certbot --nginx -d your-domain.com
```

### 安全头配置
```nginx
add_header X-Frame-Options DENY;
add_header X-Content-Type-Options nosniff;
add_header X-XSS-Protection "1; mode=block";
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";
```

## 常见问题

### Q: API 密钥配置后仍然无法使用？
A: 检查环境变量是否正确设置，确保变量名前缀为 `VITE_` 的变量在构建时会被注入到客户端代码中。

### Q: 构建失败提示内存不足？
A: 增加 Node.js 内存限制：
```bash
NODE_OPTIONS="--max-old-space-size=4096" npm run build
```

### Q: 部署后页面空白？
A: 检查路由配置，确保服务器支持 SPA 路由回退到 index.html。

### Q: 图片或静态资源加载失败？
A: 检查 `vite.config.ts` 中的 `base` 配置是否正确。

## 技术支持

如遇到部署问题，请：
1. 查看 [Issues](https://github.com/your-username/finsight-ai-financial-analysis/issues)
2. 提交新的 Issue 并提供详细的错误信息
3. 联系维护者获取帮助

---

最后更新：2025年12月10日
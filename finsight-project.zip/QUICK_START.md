# FinSight 财智眼 - 快速开始指南

## 🚀 一键部署到 GitHub

### 方法一：使用部署脚本（推荐）

1. **在 GitHub 上创建新仓库**
   - 访问 [GitHub](https://github.com/new)
   - 创建名为 `finsight-ai-financial-analysis` 的仓库
   - 不要初始化 README、.gitignore 或 LICENSE

2. **运行部署脚本**
```bash
# 替换为你的仓库 URL
./scripts/deploy-to-github.sh https://github.com/your-username/finsight-ai-financial-analysis.git
```

### 方法二：手动部署

1. **初始化 Git 仓库**
```bash
git init
git add .
git commit -m "feat: 初始化 FinSight 财智眼项目"
```

2. **添加远程仓库并推送**
```bash
git remote add origin https://github.com/your-username/finsight-ai-financial-analysis.git
git branch -M main
git push -u origin main
```

## ⚙️ 配置 GitHub 部署

### 1. 设置 Secrets

在 GitHub 仓库中设置以下 Secrets (Settings > Secrets and variables > Actions):

- `GEMINI_API_KEY`: 你的 Google Gemini API 密钥
- `DOUBAO_API_KEY`: 你的豆包 API 密钥

### 2. 启用 GitHub Pages

1. 进入仓库 Settings > Pages
2. Source 选择 "GitHub Actions"
3. 等待自动部署完成

### 3. 获取 API 密钥

**Google Gemini API Key:**
1. 访问 [Google AI Studio](https://makersuite.google.com/app/apikey)
2. 创建新的 API Key
3. 复制密钥到 GitHub Secrets

**豆包 API Key:**
1. 访问 [火山引擎控制台](https://console.volcengine.com/)
2. 创建应用并获取 API Key
3. 复制密钥到 GitHub Secrets

## 🌐 其他部署选项

### Vercel 部署

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/finsight-ai-financial-analysis)

### Netlify 部署

1. 连接 GitHub 仓库到 Netlify
2. 构建命令: `npm run build`
3. 发布目录: `dist`
4. 在环境变量中添加 API Keys

### Docker 部署

```bash
# 克隆仓库
git clone https://github.com/your-username/finsight-ai-financial-analysis.git
cd finsight-ai-financial-analysis

# 使用 Docker Compose
docker-compose up -d
```

## 🔧 本地开发

```bash
# 克隆仓库
git clone https://github.com/your-username/finsight-ai-financial-analysis.git
cd finsight-ai-financial-analysis

# 安装依赖
npm install

# 配置环境变量
cp .env.example .env.local
# 编辑 .env.local 添加你的 API Keys

# 启动开发服务器
npm run dev
```

## 📞 需要帮助？

- 📖 查看完整 [部署指南](./DEPLOYMENT.md)
- 📋 阅读 [项目介绍](./PROJECT_INTRODUCTION.md)
- 🐛 提交 [Issues](https://github.com/your-username/finsight-ai-financial-analysis/issues)

---

🎉 恭喜！你的 FinSight 财智眼应用已经成功部署到 GitHub！